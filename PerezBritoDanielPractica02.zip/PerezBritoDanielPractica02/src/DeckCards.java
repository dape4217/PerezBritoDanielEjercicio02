import java.util.ArrayList; // Lista dinámica para guardar el mazo

public class DeckCards {

    public static void main(String[] args) {

        // Palos y valores posibles
        String[] suits = { "Spades", "Diamonds", "Club", "Heart" };
        String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

        // Mazo vacío
        ArrayList<Card> deck = new ArrayList<Card>();

        // Crea las 52 cartas (4 palos x 13 valores)
        for (int i = 0; i < suits.length; i++) {
            for (int j = 0; j < values.length; j++) {
                Card card = new Card(suits[i], values[j]);
                deck.add(card); // Añade la carta al mazo
            }
        }

        // Baraja: intercambia cada carta con otra de posición aleatoria anterior
        for (int i = 0; i < deck.size(); i++) {
            int j = (int) Math.floor(Math.random() * i); // Índice aleatorio
            Card tmp = deck.get(i);   // Guarda la carta i
            deck.set(i, deck.get(j)); // Pone en i la carta j
            deck.set(j, tmp);         // Pone en j la carta guardada
        }

        // Muestra las 5 primeras cartas del mazo barajado
        for (int i = 0; i < 5; i++) {
            System.out.println(deck.get(i));
        }
    }
}