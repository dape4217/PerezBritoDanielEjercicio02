public class Card {

	    public String suit;   // Palo de la carta (Spades, Diamonds...)
	    public String value;  // Valor de la carta (Ace, 2... King)

	    // Constructor: asigna palo y valor al crear la carta
	    public Card(String suit, String value) {
	        this.suit = suit;
	        this.value = value;
	    }

	    // Devuelve la carta como texto, p. ej. "Spades-Ace"
	    public String toString() {
	        return (this.suit + "-" + this.value);
	    }
	}
